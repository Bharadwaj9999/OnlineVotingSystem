package beans;

public class OnlineVotingUserBean {
	
	private String userMailID;
	private String userCollegeID;
	private String username;
	private String password;
	private int votedAlready;
	public String getUserMailID() {
		return userMailID;
	}
	public void setUserMailID(String userMailID) {
		this.userMailID = userMailID;
	}
	public String getUserCollegeID() {
		return userCollegeID;
	}
	public void setUserCollegeID(String userCollegeID) {
		this.userCollegeID = userCollegeID;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public int getVotedAlready() {
		return votedAlready;
	}
	public void setVotedAlready(int votedAlready) {
		this.votedAlready = votedAlready;
	}
	
}
