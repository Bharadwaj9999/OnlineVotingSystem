package database;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import beans.CandidateBean;
import beans.OnlineVotingUserBean;

public class VotingDAO {
	
	public void adminAddUser(String userMailID,String userCollegeID)
	{
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/project?user=root&password=P@ssword9999");
			PreparedStatement preparedStatement=connect.prepareStatement("insert into userDetails(userMailId,userCollegeID) values(?,?)");
			preparedStatement.setString(1, userMailID);
			preparedStatement.setString(2, userCollegeID);
			preparedStatement.execute();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public List<CandidateBean> getElectionResults() {
		List<CandidateBean> candidateBean=new ArrayList<CandidateBean>();
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/project?user=root&password=P@ssword9999");
			Statement statement = connect.createStatement();
			ResultSet resultSet=null;
			resultSet=statement.executeQuery("select * from candidateDetails");
			while(resultSet.next())
			{
				CandidateBean bean=new CandidateBean();
				bean.setCandidateId(resultSet.getString(1));
				bean.setNoOfVotes(resultSet.getInt(2));
				candidateBean.add(bean);
			}
			return candidateBean;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public void castVoteUpdate(String candidateID1, String collegeID, String username) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/project?user=root&password=P@ssword9999");
			PreparedStatement preparedStatement=connect.prepareStatement("update candidateDetails set noOFVotes=noOFVotes+1 where candidateID='"+candidateID1+"'");
			preparedStatement.execute();
			PreparedStatement preparedStatement2=connect.prepareStatement("update userDetails set votedAlready=1 where userCollegeID='"+collegeID+"'");
			preparedStatement2.execute();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public boolean checkUserVotedAlready(String collegeID) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/project?user=root&password=P@ssword9999");
			Statement statement = connect.createStatement();
			ResultSet resultSet=null;
			resultSet=statement.executeQuery("select votedAlready from userDetails where userCollegeID='"+collegeID+"'");
			if(resultSet.next())
			{
				int votedAlready=resultSet.getInt(1);
				if(votedAlready==1)
				{
					return true;
				}
				else
				{
					return false;
				}
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		return true;
	}
	
	public List<OnlineVotingUserBean> getCandidateList() {
		List<OnlineVotingUserBean> candidateList=new ArrayList<OnlineVotingUserBean>();
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/project?user=root&password=P@ssword9999");
			Statement statement = connect.createStatement();
			ResultSet resultSet=null;
			resultSet=statement.executeQuery("select userCollegeID,username,userMailId from userDetails where userCollegeID in (select candidateID from candidateDetails)");
			while(resultSet.next())
			{
				OnlineVotingUserBean userBean=new OnlineVotingUserBean();
				userBean.setUserCollegeID(resultSet.getString(1));
				userBean.setUsername(resultSet.getString(2));
				userBean.setUserMailID(resultSet.getString(3));
				candidateList.add(userBean);
			}
			return candidateList;
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public void candidateUserReg(String collegeID, int i) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/project?user=root&password=P@ssword9999");
			if(i==2)
			{
				Statement statement = connect.createStatement();
				statement.executeUpdate("delete from candidateDetails where candidateID='"+collegeID+"'");
			}
			else if(i==1)
			{
				PreparedStatement preparedStatement=connect.prepareStatement("insert into candidateDetails(candidateID,noOFVotes) values(?,0)");
				preparedStatement.setString(1, collegeID);
				preparedStatement.execute();
			}
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public boolean checkCandidateReg(String collegeID) {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/project?user=root&password=P@ssword9999");
			Statement statement = connect.createStatement();
			ResultSet resultSet=null;
			resultSet=statement.executeQuery("select * from candidateDetails where candidateID='"+collegeID+"'");
			if(resultSet.next())
			{
				return true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return false;
	}
	
	public void addUserDetails(String userCollegeID, String username, String password)
	{
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/project?user=root&password=P@ssword9999");
			PreparedStatement preparedStatement=connect.prepareStatement("update userDetails set username='"+username+"', password='"+password+"',votedAlready=0 where userCollegeID='"+userCollegeID+"'");
			preparedStatement.execute();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public boolean userRegistrationCheck(String userCollegeID)
	{
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/project?user=root&password=P@ssword9999");
			Statement statement = connect.createStatement();
			ResultSet resultSet=null;
			resultSet=statement.executeQuery("select * from userdetails where userCollegeID='"+userCollegeID+"'");
			if(resultSet.next())
			{
				return false;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return true;
	}
	
	public boolean userNewRegistrationCheck(String userCollegeID)
	{
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/project?user=root&password=P@ssword9999");
			Statement statement = connect.createStatement();
			ResultSet resultSet=null;
			resultSet=statement.executeQuery("select * from userDetails where userCollegeID='"+userCollegeID+"' and username is not null");
			if(resultSet.next())
			{
				return false;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return true;
	}
	
	public void enterUserRegistrationLastDate(Date d)
	{
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/project?user=root&password=P@ssword9999");
			PreparedStatement preparedStatement=connect.prepareStatement("insert into ElectionDate values(?)");
			preparedStatement.setDate(1, d);
			preparedStatement.execute();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public String checkUserCredentials(String userCollegeID,String password)
	{
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/project?user=root&password=P@ssword9999");
			Statement statement = connect.createStatement();
			ResultSet resultSet=null;
			resultSet=statement.executeQuery("select username from userDetails where userCollegeID='"+userCollegeID+"' and password='"+password+"'");
			if(resultSet.next())
			{
				return resultSet.getString(1);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	public List<OnlineVotingUserBean> getListOfUsers(int option)
	{
		List<OnlineVotingUserBean> userBeanList=new ArrayList<OnlineVotingUserBean>();
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/project?user=root&password=P@ssword9999");
			Statement statement = connect.createStatement();
			ResultSet resultset=null;
			if(option==1)
			{
				resultset=statement.executeQuery("select userMailId,userCollegeID,username from userDetails");
			}
			else if(option==2)
			{
				resultset=statement.executeQuery("select userMailId,userCollegeID,username from userDetails where username is not null");
			}
			else if(option==3)
			{
				resultset=statement.executeQuery("select user.userMailId,user.userCollegeID,user.username from userDetails user where user.userCollegeID not in (select candidate.candidateID from candidateDetails candidate)");
			}
			else if(option==4)
			{
				resultset=statement.executeQuery("select user.userMailId,user.userCollegeID,user.username from userDetails user where user.userCollegeID in (select candidate.candidateID from candidateDetails candidate)");
			}
			else if(option==5)
			{
				resultset=statement.executeQuery("select userMailId,userCollegeID,username from userDetails where votedAlready=0");
			}
			while(resultset.next())
			{
				OnlineVotingUserBean userBean=new OnlineVotingUserBean();
				userBean.setUserMailID(resultset.getString(1));
				userBean.setUserCollegeID(resultset.getString(2));
				if(option==2 || option==4 || option==3)
				{
					userBean.setUsername(resultset.getString(3));
				}
				userBeanList.add(userBean);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return userBeanList;
	}
	
	public Date getUserRegistrationLastDate()
	{
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/project?user=root&password=P@ssword9999");
			Statement statement = connect.createStatement();
			ResultSet resultset=statement.executeQuery("select * from ElectionDate");
			if(resultset.next())
			{
				return resultset.getDate(1);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
	public boolean duplicateUserCheck(String userCollegeID,int option)
	{
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection connect = DriverManager.getConnection("jdbc:mysql://localhost:3306/project?user=root&password=P@ssword9999");
			Statement statement = connect.createStatement();
			ResultSet resultSet=null;
			if(option==1)
			{
				resultSet=statement.executeQuery("select * from userDetails where userCollegeID='"+userCollegeID+"'");
			}
			else if(option==2)
			{
				resultSet=statement.executeQuery("select * from candidateDetails where candidateID='"+userCollegeID+"'");
			}
			if(resultSet.next())
			{
				return false;
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return true;
	}
	
}
