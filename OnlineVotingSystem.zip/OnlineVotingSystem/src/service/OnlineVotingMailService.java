package service;

import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMessage.RecipientType;

public class OnlineVotingMailService {

	public void sendMail(String rec,String subject,String message)
	{
		final String fromAddress="donotreply.onlinevoting@gmail.com";
		final String password="P@ssword9999";
		
		Properties proper=new Properties();
		proper.put("mail.smtp.host","smtp.gmail.com");
		proper.put("mail.smtp.ssl.enable","true");
		proper.put("mail.smtp.auth","true");
		
		Session sess=Session.getInstance(proper, new javax.mail.Authenticator(){
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(fromAddress,password);				
			}
		});
		
		Message mess=new MimeMessage(sess);
		try {
			mess.setFrom(new InternetAddress(fromAddress));
			mess.setRecipient(RecipientType.TO, new InternetAddress(rec));
			mess.setContent(message,"text/plain");
			mess.setSubject(subject);
			
			Transport.send(mess);
		} catch (AddressException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (MessagingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
