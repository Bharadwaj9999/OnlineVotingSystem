package controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.util.Calendar;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mysql.cj.Session;

import beans.OnlineVotingUserBean;
import database.VotingDAO;
import service.OnlineVotingMailService;
import service.OnlineVotingSystemService;

@WebServlet("/AdminController")
public class AdminController extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public AdminController()
	{
		super();
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		String operation=request.getParameter("action");
		Date currDate=new Date(Calendar.getInstance().getTime().getTime());
		VotingDAO votingDao=new VotingDAO();
		PrintWriter write=response.getWriter();
		try {
			if(operation.equals("setRegDate"))
			{
				Date userDate=Date.valueOf(request.getParameter("regDate"));
				if(userDate.compareTo(currDate)<=0)
				{
					RequestDispatcher rd=request.getRequestDispatcher("/AdminMain.jsp");
					rd.include(request, response);
					write.print("<br><br><br><center><h3>User reg end date cant be less than current date!!! Please enter valid user reg end date</h3></center>");
					
				}
				else if(userDate.compareTo(OnlineVotingSystemService.addDays(currDate,30))>=0) {
					RequestDispatcher rd=request.getRequestDispatcher("/AdminMain.jsp");
					rd.include(request, response);
					write.print("<br><br><br><center><h3>User reg end date cant be 30 days more than current date!!! Please enter valid user reg end date</h3></center>");
				}
				else
				{
					votingDao.enterUserRegistrationLastDate(userDate);
					RequestDispatcher rd=request.getRequestDispatcher("/AdminMain1.jsp");
					rd.include(request, response);					
				}				
			}
			else if(operation.equals("seeListOfUsers"))
			{
				List<OnlineVotingUserBean> listOfUsers=votingDao.getListOfUsers(1);
				if(listOfUsers==null)
				{
					RequestDispatcher rd=request.getRequestDispatcher("/AdminMain1.jsp");
					rd.include(request, response);
					write.print("<br><br><br><center><h3>No users available</h3></center>");
				}
				else
				{
					request.setAttribute("listOfUsers", listOfUsers);
					RequestDispatcher rd=request.getRequestDispatcher("/AdminMain1.jsp");
					rd.include(request, response);
				}
			}
			else if(operation.equals("seeListOfRegUsers")) 
			{
				List<OnlineVotingUserBean> listOfRegUsers=votingDao.getListOfUsers(2);
				if(listOfRegUsers==null)
				{
					RequestDispatcher rd=request.getRequestDispatcher("/AdminMain1.jsp");
					rd.include(request, response);
					write.print("<br><br><br><center><h3>No registered users available</h3></center>");
				}
				else
				{
					request.setAttribute("listOfRegUsers", listOfRegUsers);
					RequestDispatcher rd=request.getRequestDispatcher("/AdminMain1.jsp");
					rd.include(request, response);
				}
			}
			else if(operation.equals("addUser"))
			{
				HttpSession session=request.getSession(false);
				String userCollegeID=request.getParameter("collegeId");
				if(OnlineVotingSystemService.validateUserCollegeID(userCollegeID))
				{
					if(votingDao.duplicateUserCheck(userCollegeID,1))
					{
						votingDao.adminAddUser(userCollegeID+"@mylambton.ca", userCollegeID);
						OnlineVotingMailService mail=new OnlineVotingMailService();
						Date userDate=Date.valueOf(session.getAttribute("userDate").toString());
						String message="Hi,\n\nYou have been added to online voting system\n\nPlease login to register before"+userDate+"\n\nThanks,\nAdmin";
						mail.sendMail(userCollegeID+"@mylambton.ca", "New notification from online voting system", message);
						RequestDispatcher rd=request.getRequestDispatcher("/AddUser.jsp");
						rd.include(request, response);
						write.print("<br><br><br><center><h3>User added and mail send successfully</h3></center>");
					}
					else
					{
						RequestDispatcher rd=request.getRequestDispatcher("/AddUser.jsp");
						rd.include(request, response);
						write.print("<br><br><br><center><h3>User already exists</h3></center>");
					}
				}
				else					
				{
					RequestDispatcher rd=request.getRequestDispatcher("/AddUser.jsp");
					rd.include(request, response);
					write.print("<br><br><br><center><h3>invalid user id format</h3></center>");
				}
			}
			else if(operation.equals("sendMessage"))
			{
				String userCollegeID=request.getParameter("collegeId");
				String message=request.getParameter("message");
				if(OnlineVotingSystemService.validateUserCollegeID(userCollegeID))
				{
					if(!votingDao.duplicateUserCheck(userCollegeID,1))
					{
						votingDao.adminAddUser(userCollegeID+"@mylambton.ca", userCollegeID);
						OnlineVotingMailService mail=new OnlineVotingMailService();
						String msg="Hi,\n\n"+message+"\n\nThanks,\nAdmin";
						mail.sendMail(userCollegeID+"@mylambton.ca", "New notification from online voting system", msg);
						RequestDispatcher rd=request.getRequestDispatcher("/SendUserMessage.jsp");
						rd.include(request, response);
						write.print("<br><br><br><center><h3>Message send successfully</h3></center>");
					}
					else
					{
						RequestDispatcher rd=request.getRequestDispatcher("/SendUserMessage.jsp");
						rd.include(request, response);
						write.print("<br><br><br><center><h3>User doesn't exists</h3></center>");
					}
				}
				else					
				{
					RequestDispatcher rd=request.getRequestDispatcher("/SendUserMessage.jsp");
					rd.include(request, response);
					write.print("<br><br><br><center><h3>invalid user id format</h3></center>");
				}
			}
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			HttpSession session=request.getSession(false);
			session.invalidate();
			RequestDispatcher rd=request.getRequestDispatcher("/StartPage.jsp");
			rd.include(request, response);
			write.print("<br><br><br><center><h3>Error occured!!!Please contact support</h3></center>");
		}
		
		
		
		
		
	}
}
