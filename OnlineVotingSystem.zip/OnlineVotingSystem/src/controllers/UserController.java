package controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.util.Calendar;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import database.VotingDAO;
import service.OnlineVotingMailService;
import service.OnlineVotingSystemService;


@WebServlet("/UserController")
public class UserController extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public UserController()
	{
		super();
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String operation=request.getParameter("action");
		VotingDAO votingDao=new VotingDAO();
		PrintWriter write=response.getWriter();
		int electionPhase=2;
		try {
			if(electionPhase==1)
			{
				if(operation.equals("userRegister"))
				{
					
					HttpSession session=request.getSession();
					String collegeId=request.getParameter("collegeId");
					if(OnlineVotingSystemService.validateUserCollegeID(collegeId))
					{
						if(!votingDao.userRegistrationCheck(collegeId))
						{
							if(votingDao.userNewRegistrationCheck(collegeId))
							{
								int randomNum=userRegMainPage(collegeId);
								session.setAttribute("otp", randomNum);
								session.setAttribute("collegeId", collegeId);
								RequestDispatcher rd=request.getRequestDispatcher("/UserOTP.jsp");
								rd.include(request, response);
							}
							else
							{
								RequestDispatcher rd=request.getRequestDispatcher("/StartPage.jsp");
								rd.include(request, response);
								write.print("<br><br><br><center><h3>you had already registered!!! Please login</h3></center>");
							}
						}
						else
						{
							RequestDispatcher rd=request.getRequestDispatcher("/StartPage.jsp");
							rd.include(request, response);
							write.print("<br><br><br><center><h3>Your ID not yet registered in database!!! Please contact admin</h3></center>");
						}
					}
					else
					{
						RequestDispatcher rd=request.getRequestDispatcher("/UserRegister.jsp");
						rd.include(request, response);
						write.print("<br><br><br><center><h3>Invalid user id format</h3></center>");
					}
				}
				else if(operation.equals("userRegisterOTPCheck"))
				{
					HttpSession session=request.getSession(false);
					int otp=Integer.valueOf(request.getParameter("otp"));
					int originalOtp=(int) session.getAttribute("otp");
					if(otp==originalOtp)
					{
						RequestDispatcher rd=request.getRequestDispatcher("/UserRegistrationPage.jsp");
						rd.include(request, response);
					}
					else
					{
						session.invalidate();
						RequestDispatcher rd=request.getRequestDispatcher("/UserRegister.jsp");
						rd.include(request, response);
						write.print("<br><br><br><center><h3>invalid otp</h3></center>");
					}
				}
				else if(operation.equals("registerUser"))
				{
					HttpSession session=request.getSession(false);
					String collegeID=session.getAttribute("collegeId").toString();
					String username=request.getParameter("username");
					String password1=request.getParameter("password1");
					String password2=request.getParameter("password2");
					if(password1.equals(password2))
					{
						votingDao.addUserDetails(collegeID,username,password1);
						RequestDispatcher rd=request.getRequestDispatcher("/StartPage.jsp");
						rd.include(request, response);
						write.print("<br><br><br><center><h3>Registered successfully!!!Login to continue</h3></center>");
					}
					else
					{
						RequestDispatcher rd=request.getRequestDispatcher("/UserRegistrationPage.jsp");
						rd.include(request, response);
						write.print("<br><br><br><center><h3>password didn't match</h3></center>");
					}
				}
			}
			else
			{
				RequestDispatcher rd=request.getRequestDispatcher("/StartPage.jsp");
				rd.include(request, response);
				write.print("<br><br><br><center><h3>User registration phase has passed away</h3></center>");
			}
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			HttpSession session=request.getSession(false);
			session.invalidate();
			RequestDispatcher rd=request.getRequestDispatcher("/StartPage.jsp");
			rd.include(request, response);
			write.print("<br><br><br><center><h3>Error occured!!!Please contact support</h3></center>");
		}
	}

	private static int userRegMainPage(String userCollegeID)
	{
		int randomNum = (int) ((Math.random()*((9999-1000)+1))+1000);
		OnlineVotingMailService mail=new OnlineVotingMailService();
		String message="Hi,\n\nYour one time password for login is:"+randomNum+"\n\ndon't share with anyone\n\nThanks,\nAdmin";
		mail.sendMail(userCollegeID+"@mylambton.ca", "One time password for login", message);
		return randomNum;
	}
}
