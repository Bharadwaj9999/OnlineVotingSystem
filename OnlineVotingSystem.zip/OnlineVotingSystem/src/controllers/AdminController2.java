package controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.util.Calendar;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import beans.OnlineVotingUserBean;
import database.VotingDAO;
import service.OnlineVotingMailService;
import service.OnlineVotingSystemService;

@WebServlet("/AdminController2")
public class AdminController2 extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public AdminController2()
	{
		super();
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String operation=request.getParameter("action");
		VotingDAO votingDao=new VotingDAO();
		PrintWriter write=response.getWriter();
		try {
			if(operation.equals("seeNotificationtoUsers"))
			{
				HttpSession session=request.getSession(false);
				List<OnlineVotingUserBean> unRegisteredUserList=votingDao.getListOfUsers(3);
				if(unRegisteredUserList.size()==0)
				{
					RequestDispatcher rd=request.getRequestDispatcher("/AdminMain2.jsp");
					rd.include(request, response);
					write.print("<br><br><br><center><h3>There are no more users left who are not candidates</h3></center>");
				}
				else
				{
					OnlineVotingMailService mail=new OnlineVotingMailService();
					Date d1=Date.valueOf(session.getAttribute("candidateRegEndDate").toString());
					for(OnlineVotingUserBean userBean:unRegisteredUserList)
					{					
						String message="Hi,\n\nCandidate registration is going on...\n\nPlease login to register before "+d1+" to see list of candidates or register yourself as a candidate\n\nThanks,\nAdmin";
						mail.sendMail(userBean.getUserCollegeID()+"@mylambton.ca", "New notification from online voting system", message);
					}
					RequestDispatcher rd=request.getRequestDispatcher("/AdminMain2.jsp");
					rd.include(request, response);
					write.print("<br><br><br><center><h3>Notification send successfully to all unregistered users as candidates</h3></center>");
				}
			}
			else if(operation.equals("seeListOfCandidates"))
			{
				List<OnlineVotingUserBean> candidateList=votingDao.getListOfUsers(4);				
				if(candidateList.size()==0)
				{
					RequestDispatcher rd=request.getRequestDispatcher("/AdminMain2.jsp");
					rd.include(request, response);
					write.print("<br><br><br><center><h3>Sorry no candidates registered for election</h3></center>");
				}
				else
				{
					request.setAttribute("ListofCandidates", candidateList);
					RequestDispatcher rd=request.getRequestDispatcher("/AdminMain2.jsp");
					rd.include(request, response);
				}
			}
			else if(operation.equals("sendMessage"))
			{
				String userCollegeID=request.getParameter("collegeId");
				String message=request.getParameter("message");
				if(OnlineVotingSystemService.validateUserCollegeID(userCollegeID))
				{
					if(!votingDao.duplicateUserCheck(userCollegeID,1))
					{
						votingDao.adminAddUser(userCollegeID+"@mylambton.ca", userCollegeID);
						OnlineVotingMailService mail=new OnlineVotingMailService();
						String msg="Hi,\n\n"+message+"\n\nThanks,\nAdmin";
						mail.sendMail(userCollegeID+"@mylambton.ca", "New notification from online voting system", msg);
						RequestDispatcher rd=request.getRequestDispatcher("/SendUserMessage2.jsp");
						rd.include(request, response);
						write.print("<br><br><br><center><h3>Message send successfully</h3></center>");
					}
					else
					{
						RequestDispatcher rd=request.getRequestDispatcher("/SendUserMessage2.jsp");
						rd.include(request, response);
						write.print("<br><br><br><center><h3>User doesn't exists</h3></center>");
					}
				}
				else					
				{
					RequestDispatcher rd=request.getRequestDispatcher("/SendUserMessage2.jsp");
					rd.include(request, response);
					write.print("<br><br><br><center><h3>invalid user id format</h3></center>");
				}
			}
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			HttpSession session=request.getSession(false);
			session.invalidate();
			RequestDispatcher rd=request.getRequestDispatcher("/StartPage.jsp");
			rd.include(request, response);
			write.print("<br><br><br><center><h3>Error occured!!!Please contact support</h3></center>");
		}
	}

}
