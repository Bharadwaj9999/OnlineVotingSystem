package controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import beans.OnlineVotingUserBean;
import database.VotingDAO;

@WebServlet("/UserController4")
public class UserController4 extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public UserController4()
	{
		super();
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String operation=request.getParameter("action");
		PrintWriter write=response.getWriter();
		VotingDAO votingDao=new VotingDAO();
		try {
			HttpSession session=request.getSession(false);
			String collegeID=session.getAttribute("collegeID").toString();
			String username=session.getAttribute("username").toString();
			if(operation.equalsIgnoreCase("castVote"))
			{
				if(votingDao.checkUserVotedAlready(collegeID))
				{
					RequestDispatcher rd=request.getRequestDispatcher("/UserMain4.jsp");
					rd.include(request, response);
					write.print("<br><br><br><center><h3>Hey "+username+" You have already casted your vote, please login tommorrow to see the election results</h3></center>");
				}
				else
				{
					List<OnlineVotingUserBean>	candidateList=votingDao.getCandidateList();
					if(candidateList.size()==0)
					{
						RequestDispatcher rd=request.getRequestDispatcher("/UserMain4.jsp");
						rd.include(request, response);
						write.print("<br><br><br><center><h3>There are no candidates standing in election</h3></center>");
					}
					else
					{
						request.setAttribute("candidateList", candidateList);
						RequestDispatcher rd=request.getRequestDispatcher("/UserMain4.jsp");
						rd.include(request, response);
					}
				}
			}
			else if(operation.equals("vote"))
			{
				if(votingDao.checkUserVotedAlready(collegeID))
				{
					RequestDispatcher rd=request.getRequestDispatcher("/UserMain4.jsp");
					rd.include(request, response);
					write.print("<br><br><br><center><h3>Hey "+username+" You have already casted your vote, please login tommorrow to see the election results</h3></center>");
				}
				else
				{
					String votedCollegeID=request.getParameter("selection");
					votingDao.castVoteUpdate(votedCollegeID,collegeID,username);
					RequestDispatcher rd=request.getRequestDispatcher("/UserMain4.jsp");
					rd.include(request, response);
					write.print("<br><br><br><center><h3>You have casted your vote successfully</h3></center>");
				}
			}
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			HttpSession session=request.getSession(false);
			session.invalidate();
			RequestDispatcher rd=request.getRequestDispatcher("/StartPage.jsp");
			rd.include(request, response);
			write.print("<br><br><br><center><h3>Error occured!!!Please contact support</h3></center>");
		}
		
	}

}
