package controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import beans.OnlineVotingUserBean;
import database.VotingDAO;
import service.OnlineVotingMailService;
import service.OnlineVotingSystemService;

@WebServlet("/AdminController4")
public class AdminController4 extends HttpServlet {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public AdminController4()
	{
		super();
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String operation=request.getParameter("action");
		PrintWriter write=response.getWriter();
		VotingDAO votingDao=new VotingDAO();
		try {
			if(operation.equalsIgnoreCase("sendNotification"))
			{
				List<OnlineVotingUserBean> unRegisteredUserList=votingDao.getListOfUsers(5);
				if(unRegisteredUserList.size()==0)
				{
					RequestDispatcher rd=request.getRequestDispatcher("/AdminMain4.jsp");
					rd.include(request, response);
					write.print("<br><br><br><center><h3>All users casted their votes</h3></center>");
				}
				else
				{
					OnlineVotingMailService mail=new OnlineVotingMailService();
					for(OnlineVotingUserBean userBean:unRegisteredUserList)
					{					
						String message="Hi,\n\nElection day is up, please log into system to cast your vote\n\nThanks,\nAdmin";
						mail.sendMail(userBean.getUserCollegeID()+"@mylambton.ca", "New notification from online voting system", message);
					}
					RequestDispatcher rd=request.getRequestDispatcher("/AdminMain4.jsp");
					rd.include(request, response);
					write.print("<br><br><br><center><h3>Notification send to users who have not yet voted</h3></center>");
				}
			}
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			HttpSession session=request.getSession(false);
			session.invalidate();
			RequestDispatcher rd=request.getRequestDispatcher("/StartPage.jsp");
			rd.include(request, response);
			write.print("<br><br><br><center><h3>Error occured!!!Please contact support</h3></center>");
		}
		
	}
		

}
