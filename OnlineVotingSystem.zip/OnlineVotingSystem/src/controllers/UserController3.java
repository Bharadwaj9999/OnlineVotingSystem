package controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.mysql.cj.Session;

import beans.OnlineVotingUserBean;
import database.VotingDAO;
import service.OnlineVotingMailService;

@WebServlet("/UserController3")
public class UserController3 extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public UserController3()
	{
		super();
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String operation=request.getParameter("action");
		VotingDAO votingDao=new VotingDAO();
		PrintWriter write=response.getWriter();
		try {
			if(operation.equals("seeListOfCandidatesCandidate")) {
				List<OnlineVotingUserBean>	candidateList=votingDao.getCandidateList();
				if(candidateList.size()==0)
				{
					RequestDispatcher rd=request.getRequestDispatcher("/UserMain3_Candidate.jsp");
					rd.include(request, response);
					write.print("<br><br><br><center><h3>No candidates in the system</h3></center>");
				}
				else
				{
					request.setAttribute("candidateList", candidateList);
					RequestDispatcher rd=request.getRequestDispatcher("/UserMain3_Candidate.jsp");
					rd.include(request, response);
				}				
			}
			else if(operation.equals("seeListOfCandidatesUser"))
			{
				List<OnlineVotingUserBean>	candidateList=votingDao.getCandidateList();
				if(candidateList.size()==0)
				{
					RequestDispatcher rd=request.getRequestDispatcher("/UserMain3_User.jsp");
					rd.include(request, response);
					write.print("<br><br><br><center><h3>No candidates in the system</h3></center>");
				}
				else
				{
					request.setAttribute("candidateList", candidateList);
					RequestDispatcher rd=request.getRequestDispatcher("/UserMain3_User.jsp");
					rd.include(request, response);
				}
			}
			else if(operation.equals("sendMessage"))
			{
				List<OnlineVotingUserBean> userList=votingDao.getListOfUsers(2);
				if(userList.size()==0)
				{
					RequestDispatcher rd=request.getRequestDispatcher("/SendAgendaMessage.jsp");
					rd.include(request, response);
					write.print("<br><br><br><center><h3>No users in the system</h3></center>");
				}
				else
				{
					HttpSession session=request.getSession(false);
					OnlineVotingMailService mail=new OnlineVotingMailService();
					String message1=request.getParameter("message");
					String username=session.getAttribute("collegeID").toString();
					for(OnlineVotingUserBean userBean:userList)
					{										
						String message="Hi "+userBean.getUsername()+",\n"+message1+"\n\nThanks,\n"+username;
						mail.sendMail(userBean.getUserCollegeID()+"@mylambton.ca", "New notification from online voting system", message);
					}
					RequestDispatcher rd=request.getRequestDispatcher("/SendAgendaMessage.jsp");
					rd.include(request, response);
					write.print("<br><br><br><center><h3>Election agenda send successfully to all users</h3></center>");
				}
			}
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			HttpSession session=request.getSession(false);
			session.invalidate();
			RequestDispatcher rd=request.getRequestDispatcher("/StartPage.jsp");
			rd.include(request, response);
			write.print("<br><br><br><center><h3>Error occured!!!Please contact support</h3></center>");
		}
	}
		

}
