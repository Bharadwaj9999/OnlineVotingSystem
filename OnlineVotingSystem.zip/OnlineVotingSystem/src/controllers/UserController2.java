package controllers;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import database.VotingDAO;

@WebServlet("/UserController2")
public class UserController2 extends HttpServlet{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public UserController2() {
		super();
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String operation=request.getParameter("action");
		VotingDAO votingDao=new VotingDAO();
		PrintWriter write=response.getWriter();
		try {
			HttpSession session=request.getSession(false);
			String collegeID=session.getAttribute("collegeID").toString();
			if(operation.equals("optOutAsCandidate"))
			{
				String choice=request.getParameter("selection");
				if(choice.equals("yes"))
				{
					votingDao.candidateUserReg(collegeID,2);
					RequestDispatcher rd=request.getRequestDispatcher("/UserMain2_1.jsp");
					rd.include(request, response);
				}
				else
				{
					RequestDispatcher rd=request.getRequestDispatcher("/UserMain2.jsp");
					rd.include(request, response);					
				}
			}
			else if(operation.equals("standAsCandidate"))
			{
				String choice=request.getParameter("selection");
				if(choice.equals("yes"))
				{
					votingDao.candidateUserReg(collegeID,1);
					RequestDispatcher rd=request.getRequestDispatcher("/UserMain2.jsp");
					rd.include(request, response);
				}
				else
				{
					RequestDispatcher rd=request.getRequestDispatcher("/UserMain2_1.jsp");
					rd.include(request, response);
				}
			}
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
			HttpSession session=request.getSession(false);
			session.invalidate();
			RequestDispatcher rd=request.getRequestDispatcher("/StartPage.jsp");
			rd.include(request, response);
			write.print("<br><br><br><center><h3>Error occured!!!Please contact support</h3></center>");
		}
	}

}
