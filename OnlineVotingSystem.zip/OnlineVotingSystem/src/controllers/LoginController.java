package controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import beans.CandidateBean;
import database.VotingDAO;
import service.OnlineVotingSystemService;

@WebServlet("/LoginController")
public class LoginController extends HttpServlet {

	private static final long serialVersionUID = 1L;
	
	public LoginController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		OnlineVotingSystemService service=new OnlineVotingSystemService();
		String operation=request.getParameter("action");
		PrintWriter write=response.getWriter();
		int electionPhase=2;
		VotingDAO votingDao=new VotingDAO();
		if(operation.equalsIgnoreCase("login"))
		{
			String username=request.getParameter("username");
			String password=request.getParameter("password");
			if(username.equals("admin") && password.equals("admin"))
			{
				HttpSession session=request.getSession(true);
				session.setAttribute("username", "admin");
				Date userDate=votingDao.getUserRegistrationLastDate();
				if(userDate!=null)
				{
					session.setAttribute("userDate", userDate);
					session.setAttribute("candidateRegEndDate",OnlineVotingSystemService.addDays(userDate,10));
					session.setAttribute("electionPrepareDate", OnlineVotingSystemService.addDays(userDate,15));
					session.setAttribute("electionDate", OnlineVotingSystemService.addDays(userDate,20));
				}
				if(userDate==null)
				{
					RequestDispatcher rd=request.getRequestDispatcher("/AdminMain.jsp");
					rd.include(request, response);
				}
				else if(electionPhase==1)
				{
					RequestDispatcher rd=request.getRequestDispatcher("/AdminMain1.jsp");
					rd.include(request, response);
					write.print("<br><br><br><center><h3>Welcome Admin</h3></center>");
				}
				else if(electionPhase==2)
				{
					RequestDispatcher rd=request.getRequestDispatcher("/AdminMain2.jsp");
					rd.include(request, response);
					write.print("<br><br><br><center><h3>Welcome Admin</h3></center>");
				}
				else if(electionPhase==3)
				{
					RequestDispatcher rd=request.getRequestDispatcher("/AdminMain3.jsp");
					rd.include(request, response);
					write.print("<br><br><br><center><h3>Welcome Admin</h3></center>");
				}
				else if(electionPhase==4)
				{
					RequestDispatcher rd=request.getRequestDispatcher("/AdminMain4.jsp");
					rd.include(request, response);
					write.print("<br><br><br><center><h3>Welcome Admin</h3></center>");
				}
				else if(electionPhase==5)
				{
					List<CandidateBean> results=votingDao.getElectionResults();
					request.setAttribute("results", results);
					RequestDispatcher rd=request.getRequestDispatcher("/ElectionResults.jsp");
					rd.include(request, response);
				}
			}
			else
			{
				String uname=service.checkUserLogin(username, password);
				if(uname!=null)
				{
					HttpSession session=request.getSession(true);
					session.setAttribute("username", uname);
					session.setAttribute("collegeID", username);
					Date userDate=votingDao.getUserRegistrationLastDate();
					if(userDate!=null)
					{
						session.setAttribute("userDate", userDate);
						session.setAttribute("candidateRegEndDate",OnlineVotingSystemService.addDays(userDate,10));
						session.setAttribute("electionPrepareDate", OnlineVotingSystemService.addDays(userDate,15));
						session.setAttribute("electionDate", OnlineVotingSystemService.addDays(userDate,20));
					}
					if(userDate==null)
					{
						RequestDispatcher rd=request.getRequestDispatcher("/UserMain.jsp");
						rd.include(request, response);
						write.print("<br><br><br><center><h3>Welcome "+uname+"</h3><br><br><h4>Still the election dates are not finalized!!!Please come after some time</h4></center>");
					}
					else if(electionPhase==1)
					{
						RequestDispatcher rd=request.getRequestDispatcher("/UserMain1.jsp");
						rd.include(request, response);
					}
					else if(electionPhase==2)
					{
						if(votingDao.checkCandidateReg(username))
						{
							RequestDispatcher rd=request.getRequestDispatcher("/UserMain2.jsp");
							rd.include(request, response);
						}
						else
						{
							RequestDispatcher rd=request.getRequestDispatcher("/UserMain2_1.jsp");
							rd.include(request, response);
						}
						
					}
					else if(electionPhase==3)
					{
						if(votingDao.checkCandidateReg(username))
						{
							RequestDispatcher rd=request.getRequestDispatcher("/UserMain3_Candidate.jsp");
							rd.include(request, response);
							write.print("<br><br><br><center><h3>Welcome Admin</h3></center>");
						}
						else
						{
							RequestDispatcher rd=request.getRequestDispatcher("/UserMain3_User.jsp");
							rd.include(request, response);
							write.print("<br><br><br><center><h3>Welcome Admin</h3></center>");
						}
					}
					else if(electionPhase==4)
					{
						RequestDispatcher rd=request.getRequestDispatcher("/UserMain4.jsp");
						rd.include(request, response);
						write.print("<br><br><br><center><h3>Welcome Admin</h3></center>");
					}
					else if(electionPhase==5)
					{
						List<CandidateBean> results=votingDao.getElectionResults();
						request.setAttribute("results", results);
						RequestDispatcher rd=request.getRequestDispatcher("/ElectionResults.jsp");
						rd.include(request, response);
					}
				}
				else
				{
					RequestDispatcher rd=request.getRequestDispatcher("/StartPage.jsp");
					rd.include(request, response);
					write.print("<font color=red>invalid login details</font>");
				}
			}
		}
	}
}
